import javax.swing.*;

import java.lang.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Game extends JFrame implements ActionListener{
 
	private int m_Columns=8;         
	private int m_Rows=9;
	
	private int m_PlayerFlag;
	
	private Mode m_PlayMode;
	 
	private Map m_Map;      
	 
	private Table m_Table;  //layout
	 
	private RoundButton[][] m_RoundButton;//chess pieces
	
	private int m_WinFlag=0;
	 
	private JButton m_SetGame;//set button
	 
	private JButton m_StartGame;//start button
	 
	private JButton m_NewGame;//new button
	 
	private JButton m_Exit;   //exit button
	 
	private InfoShow m_InfoBoard;
	 
	private UserInfo m_User1Board,m_User2Board;//player info
	
	private SetDialog m_dialog;
	
	
	
	String imagePath = "res/bk.jpg";//background
	ImagePanel panel;
	
	
	public Game()
	{
		
		InitGame();
	}
	//initiation
	public void InitGame() 
	{
		m_PlayerFlag=1;
		Container container=getContentPane();
		
		
		GridLayout tableLayout=new GridLayout(m_Rows,m_Columns);
		
		m_PlayMode=new Mode();
		//inial layout
		m_Table=new Table(tableLayout);
		m_Table.setBackground(Color.white);
		
		m_InfoBoard=new InfoShow();
		m_RoundButton=new RoundButton[m_Rows][m_Columns];
		
		m_User1Board=new UserInfo("p1",Color.blue);
		m_User2Board=new UserInfo("ai",Color.red);
		
		m_InfoBoard.SetP1Name(m_User1Board.m_Name);
		m_InfoBoard.SetP2Name(m_User2Board.m_Name);
		
		//add button and LISTENER
		ImageIcon StartIcon=new ImageIcon("res/start.jpg");
		ImageIcon NewIcon=new ImageIcon("res/new.jpg");
		ImageIcon ExitIcon=new ImageIcon("res/exit.jpg");
		ImageIcon SetIcon=new ImageIcon("res/set.jpg");
		
		m_SetGame=new JButton(SetIcon);
		m_SetGame.addActionListener(this);
		
		m_StartGame=new JButton(StartIcon);
		m_StartGame.addActionListener(this);
		
		m_NewGame=new JButton(NewIcon);
		m_NewGame.addActionListener(this);
		
		m_Exit=new JButton(ExitIcon);
		m_Exit.addActionListener(this);
		
		//add chess pieces
		for(int i=0;i<m_Rows;i++)
		{
			for(int j=0;j<m_Columns;j++)
			{
				m_RoundButton[i][j]=new RoundButton();
				
				m_RoundButton[i][j].addActionListener(this);
				
				m_RoundButton[i][j].setEnabled(false);
				
				m_Table.add(m_RoundButton[i][j]);
			}
		}
		
		//show background
		panel=new ImagePanel(imagePath);
		
		
		//this.add(panel);
		
		
		//add all object
		container.add(m_StartGame);
		container.add(m_NewGame);
		container.add(m_SetGame);
		container.add(m_Exit);
		container.add(m_Table);
		container.add(m_InfoBoard);
		container.add(m_User1Board);
		container.add(m_User2Board);
		container.add(panel);
		container.setLayout(null);
		m_Table.setBounds(20,20,m_Columns*48,m_Rows*48);
		m_InfoBoard.setBounds(440,200,160,80);
		m_User1Board.setBounds(440,20,160,100);
		m_User2Board.setBounds(440,360,160,100);
		
		m_StartGame.setBounds(20,480,79,38);
		m_NewGame.setBounds(120,480,79,38);
		m_Exit.setBounds(218,480,79,38);
		m_SetGame.setBounds(316,480,85,38);
		
		panel.setBounds(0,0,640, 580);
	}
	
	//set pramameter
	public void SetGame() 
	{
		m_dialog=new SetDialog(this,m_PlayMode,m_User1Board,m_User2Board,m_InfoBoard);
		m_dialog.show();
		
		//m_User1Board.UpdateUserInfo();
		//m_User2Board.UpdateUserInfo();
		m_InfoBoard.SetP1Name(m_User1Board.m_Name);
		m_InfoBoard.SetP2Name(m_User2Board.m_Name);
		
	}
	 
	//start game
	public void StartGame() 
	{
		m_Map=new Map(m_Rows,m_Columns);
		m_InfoBoard.ShowMessage();
		
		
		for(int i=0;i<m_Rows;i++)
		{
			for(int j=0;j<m_Columns;j++)
			{
				
				m_RoundButton[i][j].setEnabled(true);
				
			}
		}
		m_StartGame.setEnabled(false);
	}
	
	//end game
	public void StopGame()
	{
		for(int i=0;i<m_Rows;i++)
		{
			for(int j=0;j<m_Columns;j++)
			{
				
				m_RoundButton[i][j].setEnabled(false);
				
			}
		}
	}
	 
	 //new game
	public void NewGame() 
	{
		//InitGame();
		//StartGame();
		m_WinFlag=0;
		m_InfoBoard.EqualFlag=0;
		m_PlayerFlag=1;
		m_InfoBoard.SetPlayerFlag(m_PlayerFlag);
		m_InfoBoard.WinFlag=0;
		m_Map=new Map(m_Rows,m_Columns);
		m_InfoBoard.ShowMessage();
		for(int i=0;i<m_Rows;i++)
		{
			for(int j=0;j<m_Columns;j++)
			{
				
				m_RoundButton[i][j].setEnabled(true);
				m_RoundButton[i][j].hitFlag=0;
				m_RoundButton[i][j].setBackground(getBackground());
				
				
			}
		}
	}
	
	//exit game
	public void Exit() 
	{
		dispose();
	}
	
	//add ACTION
	public void actionPerformed(ActionEvent e) 
	{
		// Object obj = e.getSource();
		if (e.getSource().equals(m_StartGame))
		{
			StartGame();
		}
		
		if (e.getSource().equals(m_SetGame))
		{
			SetGame();
		}
		
		if (e.getSource().equals(m_NewGame))
		{
			NewGame();
		}
		
		if (e.getSource().equals(m_Exit))
		{
			Exit();
		}
        
		//add action for every chess pieces( how to chess)
		for (int i = 0; i < m_Rows; i++) 
		{
			for (int j = 0; j < m_Columns; j++) 
			{
				if (e.getSource().equals(m_RoundButton[i][j])) 
				{ 
					//pvp mode
					if (m_PlayMode.PlayMode == 1) 
					{
						System.out.println("mousePressed()");
						//Determine whether the player can play the game at the moment��1yes��0no��
						if (m_PlayerFlag == 1) 
						{
							if (m_RoundButton[m_Map.Place(j)][j].hitFlag == 0) 
							{
								m_RoundButton[m_Map.Place(j)][j]
										.setBackground(m_User1Board.m_Color);
								m_RoundButton[m_Map.Place(j)][j].hitFlag = m_PlayerFlag;
								
								m_Map.SetPlayer(m_PlayerFlag,m_Map.Place(j),j);//set map
								
								m_Map.m_Count--;
								
								if(m_Map.IsEqual())//Judge the level
								{
									System.out.println("equal");
									m_InfoBoard.EqualFlag=1;
									m_InfoBoard.ShowEqual();
								}
								
								//Deciding whether to win or not
								if(m_Map.IsWin(m_Map.Place(j),j,m_PlayerFlag))
								{
									System.out.println("end");
									m_InfoBoard.ShowWin();
									StopGame();
								}
								
								
								m_Map.AddPlace(j);
								m_PlayerFlag = 2;
								m_InfoBoard.SetPlayerFlag(2);
								m_InfoBoard.ShowMessage();
							}
						} 
						//the other person chesses
						else 
						{
							if (m_RoundButton[m_Map.Place(j)][j].hitFlag == 0) 
							{
								m_RoundButton[m_Map.Place(j)][j]
										.setBackground(m_User2Board.m_Color);
								m_RoundButton[m_Map.Place(j)][j].hitFlag = m_PlayerFlag;
								
								m_Map.SetPlayer(m_PlayerFlag,m_Map.Place(j),j);//set map
								
								
								
								m_Map.m_Count--;
								if(m_Map.IsEqual())//Judge the level
								{
									System.out.println("equal");
									m_InfoBoard.EqualFlag=1;
									m_InfoBoard.ShowEqual();
								}
								
								if(m_Map.IsWin(m_Map.Place(j),j,m_PlayerFlag))
								{
									System.out.println("end");
									m_InfoBoard.ShowWin();
									
									StopGame();
								}
								
								m_Map.AddPlace(j);
								
								m_PlayerFlag = 1;
								m_InfoBoard.SetPlayerFlag(1);
								m_InfoBoard.ShowMessage();
							}
						}
					} 
					//p v ai
					else 
					{
                        //person
						if (m_RoundButton[m_Map.Place(j)][j].hitFlag == 0) 
						{
							m_RoundButton[m_Map.Place(j)][j]
									.setBackground(m_User1Board.m_Color);
							m_RoundButton[m_Map.Place(j)][j].hitFlag = m_PlayerFlag;
							
							
							m_Map.SetPlayer(m_PlayerFlag,m_Map.Place(j),j);//���õ�ͼ
							
							
							
							
							
							m_Map.m_Count--;
							if(m_Map.IsEqual())//Judge the level
							{
								System.out.println("equal");
								m_InfoBoard.EqualFlag=1;
								m_InfoBoard.ShowEqual();
							}
							
							
							//Deciding whether to win or not
							if(m_Map.IsWin(m_Map.Place(j),j,m_PlayerFlag))
							{
								System.out.println("end");
								m_WinFlag=1;
								m_InfoBoard.ShowWin();
								StopGame();
							}
							
							m_Map.AddPlace(j);
							
							m_PlayerFlag = 2;
							m_InfoBoard.SetPlayerFlag(2);
							m_InfoBoard.ShowMessage();
						}

						// ai 
						if (m_WinFlag==0&&m_PlayerFlag == 2) 
						{
							//Thread.currentThread().sleep(500);
							
							int temp = m_Map.ComputerAiPlace();
							
							while (m_RoundButton[m_Map.Place(temp)][temp].hitFlag != 0) {
								temp = m_Map.ComputerPlace();
							}
							

							m_RoundButton[m_Map.Place(temp)][temp]
									.setBackground(m_User2Board.m_Color);
							m_RoundButton[m_Map.Place(temp)][temp].hitFlag = m_PlayerFlag;
							
							
							m_Map.SetPlayer(m_PlayerFlag,m_Map.Place(temp),temp);//set map
							
							
							
							m_Map.m_Count--;
							if(m_Map.IsEqual())//judge the level
							{
								System.out.println("equal");
								m_InfoBoard.EqualFlag=1;
								m_InfoBoard.ShowEqual();
							}
							
							if(m_Map.IsWin(m_Map.Place(temp),temp,m_PlayerFlag))
							{
								System.out.println("end");
								m_InfoBoard.ShowWin();
								StopGame();
							}
							
							m_Map.AddPlace(temp);
							
							m_PlayerFlag = 1;							
							m_InfoBoard.SetPlayerFlag(1);
							m_InfoBoard.ShowMessage();
						}

					}
				}

			}
		}
	}
	
		/*
		 * JButton button = (JButton) e.getSource();
		 * 
		 * button.setBackground(Color.red);
		 * System.out.println("mousePressed()");
		 */

	
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Game panel=new Game();
		panel.setTitle("Connect4");
		panel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		panel.setSize(640, 600);
		
		//Middle form
		Dimension screenSize=Toolkit.getDefaultToolkit().getScreenSize();
		int ScreenWidth=screenSize.width;
		int ScreenHeight=screenSize.height;
		
		int x=(ScreenWidth-panel.getWidth())/2;
		int y=(ScreenHeight-panel.getHeight())/2;
		panel.setLocation(x, y);
		
		panel.setVisible(true);

	}
	 
}


class Mode
{
	public int PlayMode=0;
	
}
 
